export default function ReadPage() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-2xl font-bold">📖 Leitura</h1>
      <div className="bg-white rounded p-4 mt-4">Exemplo de texto do livro</div>
    </main>
  );
}
